//
//  ViewController.h
//  Notification
//
//  Created by Ikhsan Assaat on 26/03/2017.
//  Copyright © 2017 ikhsan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
